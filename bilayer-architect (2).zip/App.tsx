import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Dna, 
  Info, 
  RefreshCw, 
  ArrowRight, 
  ShieldCheck, 
  Thermometer, 
  Zap,
  Activity,
  Award,
  HelpCircle,
  CheckCircle2,
  XCircle,
  Loader2
} from 'lucide-react';
import { Level, PlacedMolecule, Position, MoleculeType, QuizQuestion } from './types';
import { 
  PhospholipidSVG, 
  CholesterolSVG, 
  IntegralProteinSVG, 
  PeripheralProteinSVG, 
  CarbohydrateSVG
} from './constants';
import { getEducationalFeedback, generateQuizQuestion } from './services/geminiService';

const GRID_SIZE_X = 50;
const TOP_LAYER_Y = 120; 
const BOTTOM_LAYER_Y = 280; 
const CORE_Y = 200;

const LEVEL_CONCEPTS = {
  [Level.LIPID_LOGIC]: "Phospholipid Bilayer Structure and the Amphipathic nature of lipids",
  [Level.FLUIDITY_FLUX]: "Role of Cholesterol in maintaining membrane fluidity and stability",
  [Level.MOSAIC_MIX]: "Difference between Integral and Peripheral Membrane Proteins and their placement",
  [Level.IDENTITY_CHECK]: "The Glycocalyx, Glycoproteins, and their role in cell identity",
  [Level.SELECTIVITY_TEST]: "Selective Permeability and the types of molecules that require transport proteins"
};

const App: React.FC = () => {
  const [level, setLevel] = useState<Level>(Level.LIPID_LOGIC);
  const [molecules, setMolecules] = useState<PlacedMolecule[]>([]);
  const [feedback, setFeedback] = useState<string>("Welcome Architect. Drag phospholipids to the assembly zone to begin.");
  const [fluidity, setFluidity] = useState(50);
  const [temperature, setTemperature] = useState(50);
  const [homeostasisTimer, setHomeostasisTimer] = useState(10);
  const [score, setScore] = useState(0);
  const [draggedType, setDraggedType] = useState<MoleculeType | null>(null);
  const [previewPos, setPreviewPos] = useState<Position | null>(null);
  
  // Quiz State
  const [showQuiz, setShowQuiz] = useState(false);
  const [currentQuiz, setCurrentQuiz] = useState<QuizQuestion | null>(null);
  const [quizLoading, setQuizLoading] = useState(false);
  const [quizFeedback, setQuizFeedback] = useState<{ correct: boolean, text: string } | null>(null);

  const tempCycleRef = useRef<number>(0);

  const PHOSPHO_COUNT = 16;
  const CHOLESTEROL_GOAL = 6;
  const PROTEIN_GOAL = 4;
  const CARB_GOAL = 4;

  const updateFeedback = async (concept: string, event: string) => {
    const text = await getEducationalFeedback(concept, event);
    setFeedback(text);
  };

  useEffect(() => {
    if (level === Level.FLUIDITY_FLUX) {
      const interval = setInterval(() => {
        tempCycleRef.current += 0.05;
        const newTemp = 50 + Math.sin(tempCycleRef.current) * 40;
        setTemperature(newTemp);
        
        const cholesterolCount = molecules.filter(m => m.type === 'cholesterol').length;
        const baseFluidity = newTemp;
        const bufferedFluidity = baseFluidity + (50 - baseFluidity) * (cholesterolCount / 10);
        setFluidity(bufferedFluidity);

        if (bufferedFluidity < 20 || bufferedFluidity > 80) {
          if (homeostasisTimer > 0) setFeedback("Warning: Fluidity out of range! Add cholesterol to stabilize.");
        }
      }, 100);
      return () => clearInterval(interval);
    }
  }, [level, molecules, homeostasisTimer]);

  useEffect(() => {
    if (level === Level.SELECTIVITY_TEST || level === Level.WIN) {
      const interval = setInterval(() => {
        setHomeostasisTimer(prev => {
          if (prev <= 0) {
            // Level 5 is special - completion triggers the "Proceed to Certification" 
            // but the interval logic might try to setLevel(Level.WIN) immediately.
            // Let's rely on the quiz for the final jump to WIN.
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [level]);

  const getSnappedX = (x: number) => {
    return Math.floor(x / GRID_SIZE_X) * GRID_SIZE_X + GRID_SIZE_X / 2;
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    if (!draggedType) return;
    
    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    const snappedX = getSnappedX(x);
    let snappedY = y;

    if (draggedType === 'phospholipid') {
      snappedY = y < CORE_Y ? TOP_LAYER_Y : BOTTOM_LAYER_Y;
    } else if (draggedType === 'cholesterol') {
      snappedY = CORE_Y;
    } else if (draggedType === 'integral-protein') {
      snappedY = CORE_Y;
    } else if (draggedType === 'peripheral-protein') {
      snappedY = y < CORE_Y ? TOP_LAYER_Y : BOTTOM_LAYER_Y;
    } else if (draggedType === 'carbohydrate') {
      snappedY = TOP_LAYER_Y - 30;
    }

    setPreviewPos({ x: snappedX, y: snappedY });
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setPreviewPos(null);
    if (!draggedType) return;

    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const snappedX = getSnappedX(x);

    if (level === Level.LIPID_LOGIC && draggedType === 'phospholipid') {
      const isTop = y < CORE_Y;
      const targetY = isTop ? TOP_LAYER_Y : BOTTOM_LAYER_Y;
      const rotation = isTop ? 0 : 180;
      const exists = molecules.find(m => m.pos.x === snappedX && m.pos.y === targetY);
      if (exists) {
        setFeedback("Placement blocked: A phospholipid already occupies this slot.");
        return;
      }
      const newMolecule: PlacedMolecule = {
        id: Math.random().toString(),
        type: draggedType,
        pos: { x: snappedX, y: targetY },
        rotation,
        layer: isTop ? 'top' : 'bottom'
      };
      setMolecules([...molecules, newMolecule]);
      setScore(prev => prev + 50);
      const count = molecules.filter(m => m.type === 'phospholipid').length + 1;
      if (count === PHOSPHO_COUNT) {
        updateFeedback("Bilayer Architecture", "Structural alignment complete.");
      }
    }

    if (level === Level.FLUIDITY_FLUX && draggedType === 'cholesterol') {
      if (y > 150 && y < 250) {
        const exists = molecules.find(m => m.pos.x === snappedX && m.pos.y === CORE_Y && m.type === 'cholesterol');
        if (exists) return;
        const newMolecule: PlacedMolecule = {
          id: Math.random().toString(),
          type: draggedType,
          pos: { x: snappedX, y: CORE_Y }
        };
        setMolecules([...molecules, newMolecule]);
        setScore(prev => prev + 75);
      } else {
        setFeedback("Cholesterol placement must be within the hydrophobic tail region (core).");
      }
    }

    if (level === Level.MOSAIC_MIX) {
      if (draggedType === 'peripheral-protein') {
        if (y > 160 && y < 240) {
          setFeedback("Invalid Placement: Peripheral proteins bind to polar surfaces, not the hydrophobic core.");
          return;
        }
        const isTop = y < CORE_Y;
        const targetY = isTop ? TOP_LAYER_Y : BOTTOM_LAYER_Y;
        const exists = molecules.find(m => m.pos.x === snappedX && m.pos.y === targetY);
        if (exists) {
          setFeedback("Placement blocked: Docking site occupied.");
          return;
        }
        const newMolecule: PlacedMolecule = {
          id: Math.random().toString(),
          type: draggedType,
          pos: { x: snappedX, y: targetY },
          rotation: 0
        };
        setMolecules([...molecules, newMolecule]);
        setScore(prev => prev + 150);
      } else if (draggedType === 'integral-protein') {
        const targetY = CORE_Y;
        const exists = molecules.find(m => m.pos.x === snappedX && m.pos.y === targetY);
        if (exists) {
          setFeedback("Slot occupied.");
          return;
        }
        const newMolecule: PlacedMolecule = {
          id: Math.random().toString(),
          type: draggedType,
          pos: { x: snappedX, y: targetY },
          rotation: 0
        };
        setMolecules([...molecules, newMolecule]);
        setScore(prev => prev + 150);
      }
    }

    if (level === Level.IDENTITY_CHECK && draggedType === 'carbohydrate') {
      const target = molecules.find(m => m.pos.x === snappedX && m.pos.y === TOP_LAYER_Y);
      if (target) {
        const exists = molecules.find(m => m.attachedToId === target.id);
        if (exists) return;
        const newMolecule: PlacedMolecule = {
          id: Math.random().toString(),
          type: draggedType,
          pos: { x: snappedX, y: TOP_LAYER_Y - 30 },
          attachedToId: target.id
        };
        setMolecules([...molecules, newMolecule]);
        setScore(prev => prev + 200);
      } else {
        setFeedback("Glycosylation requires attachment to an extracellular protein or lipid head.");
      }
    }
  };

  const handleStartQuiz = async () => {
    setQuizLoading(true);
    setShowQuiz(true);
    setQuizFeedback(null);
    const concept = LEVEL_CONCEPTS[level] || "Cell Biology";
    const question = await generateQuizQuestion(concept);
    setCurrentQuiz(question);
    setQuizLoading(false);
  };

  const handleAnswer = (index: number) => {
    if (!currentQuiz) return;
    if (index === currentQuiz.correctIndex) {
      setQuizFeedback({ correct: true, text: `Correct! ${currentQuiz.explanation}` });
      setScore(prev => prev + 500);
      setTimeout(() => {
        setShowQuiz(false);
        setLevel(prev => prev + 1);
        if (level < Level.SELECTIVITY_TEST) {
          setFeedback(`Advancing to Stage 0${level + 1}. Monitoring environmental shifts.`);
        } else {
          setFeedback("Architect session complete. Homeostasis stabilized.");
        }
      }, 3000);
    } else {
      setQuizFeedback({ correct: false, text: "Incorrect. Analyzing structural deficiencies... try again." });
      // Allow retry after a short delay
      setTimeout(() => setQuizFeedback(null), 1500);
    }
  };

  const resetGame = () => {
    setLevel(Level.LIPID_LOGIC);
    setMolecules([]);
    setScore(0);
    setHomeostasisTimer(10);
    setFeedback("Architect session reset. Begin framework assembly.");
    setShowQuiz(false);
  };

  const isLevelComplete = 
    (level === Level.LIPID_LOGIC && molecules.filter(m => m.type === 'phospholipid').length >= PHOSPHO_COUNT) ||
    (level === Level.FLUIDITY_FLUX && molecules.filter(m => m.type === 'cholesterol').length >= CHOLESTEROL_GOAL && fluidity > 35 && fluidity < 65) ||
    (level === Level.MOSAIC_MIX && molecules.filter(m => m.type.includes('protein')).length >= PROTEIN_GOAL) ||
    (level === Level.IDENTITY_CHECK && molecules.filter(m => m.type === 'carbohydrate').length >= CARB_GOAL) ||
    (level === Level.SELECTIVITY_TEST && homeostasisTimer <= 0);

  return (
    <div className="h-screen w-screen flex flex-col bg-slate-950 text-slate-100 selection:bg-cyan-500/30">
      <header className="h-16 px-6 border-b border-white/10 flex items-center justify-between bg-slate-900/50 backdrop-blur-md z-50">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-cyan-500/20 rounded-lg">
            <Dna className="w-6 h-6 text-cyan-400" />
          </div>
          <h1 className="text-xl font-bold tracking-tight uppercase italic">Bilayer Architect</h1>
        </div>
        <div className="flex items-center gap-8">
          <div className="flex flex-col items-end">
            <span className="text-[10px] uppercase text-slate-500 font-bold tracking-tighter">Current Level</span>
            <span className="text-sm font-bold text-cyan-400">0{level > 5 ? 5 : level} / 05</span>
          </div>
          <div className="flex flex-col items-end">
            <span className="text-[10px] uppercase text-slate-500 font-bold tracking-tighter">Homeostasis Score</span>
            <span className="text-sm font-bold mono text-emerald-400">{score.toString().padStart(6, '0')}</span>
          </div>
          <button onClick={resetGame} className="p-2 hover:bg-white/10 rounded-full transition-colors" title="Reset Simulation">
            <RefreshCw className="w-5 h-5 text-slate-400" />
          </button>
        </div>
      </header>

      <main className="flex-1 flex overflow-hidden relative">
        <aside className="w-72 bg-slate-900/30 border-r border-white/10 p-6 flex flex-col gap-6 overflow-y-auto">
          <h2 className="text-xs font-bold text-slate-500 uppercase tracking-widest flex items-center gap-2">
            <Zap className="w-3 h-3" /> Molecule Forge
          </h2>
          <div className="space-y-4">
            {(['phospholipid', 'cholesterol', 'integral-protein', 'peripheral-protein', 'carbohydrate'] as MoleculeType[]).map((type) => {
              const isActive = (
                (level === Level.LIPID_LOGIC && type === 'phospholipid') ||
                (level === Level.FLUIDITY_FLUX && type === 'cholesterol') ||
                (level === Level.MOSAIC_MIX && (type === 'integral-protein' || type === 'peripheral-protein')) ||
                (level === Level.IDENTITY_CHECK && type === 'carbohydrate')
              );
              return (
                <div 
                  key={type}
                  draggable={isActive}
                  onDragStart={() => setDraggedType(type)}
                  onDragEnd={() => { setDraggedType(null); setPreviewPos(null); }}
                  className={`p-4 rounded-xl border transition-all cursor-grab active:cursor-grabbing group ${
                    isActive 
                    ? 'bg-slate-800 border-white/10 hover:border-cyan-500/50 hover:bg-slate-800/80 shadow-lg' 
                    : 'bg-slate-900/50 border-white/5 opacity-40 cursor-not-allowed'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-semibold capitalize text-slate-300">{type.replace('-', ' ')}</span>
                  </div>
                  <div className="h-16 flex items-center justify-center bg-slate-950/50 rounded-lg group-hover:bg-slate-950 transition-colors">
                    {type === 'phospholipid' && <PhospholipidSVG />}
                    {type === 'cholesterol' && <CholesterolSVG />}
                    {type === 'integral-protein' && <div className="scale-50"><IntegralProteinSVG /></div>}
                    {type === 'peripheral-protein' && <PeripheralProteinSVG />}
                    {type === 'carbohydrate' && <CarbohydrateSVG />}
                  </div>
                </div>
              );
            })}
          </div>
          <div className="mt-auto pt-6 border-t border-white/5">
            <div className="flex items-center gap-2 text-slate-400 mb-2">
              <Info className="w-4 h-4 text-cyan-400" />
              <span className="text-xs font-bold uppercase">Feedback Loop</span>
            </div>
            <div className="bg-cyan-950/20 p-3 rounded-lg border border-cyan-500/20">
              <p className="text-xs leading-relaxed text-cyan-200/80 italic">"{feedback}"</p>
            </div>
          </div>
        </aside>

        <section 
          className="flex-1 relative bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-slate-900 via-slate-950 to-black overflow-hidden"
          onDragOver={handleDragOver}
          onDrop={handleDrop}
          onDragLeave={() => setPreviewPos(null)}
        >
          <div className="absolute inset-0 opacity-[0.03] pointer-events-none" 
               style={{ 
                 backgroundImage: `linear-gradient(to right, white 1px, transparent 1px), linear-gradient(to bottom, white 1px, transparent 1px)`,
                 backgroundSize: `${GRID_SIZE_X}px 100px` 
               }} 
          />
          <div className="absolute top-8 left-1/2 -translate-x-1/2 text-[10px] uppercase font-bold text-slate-500 tracking-[0.4em] opacity-40">Extracellular Space (ECF)</div>
          <div className="absolute bottom-8 left-1/2 -translate-x-1/2 text-[10px] uppercase font-bold text-slate-500 tracking-[0.4em] opacity-40">Cytoplasm (ICF)</div>

          <div className="absolute inset-0 flex flex-col justify-center items-center pointer-events-none">
            <div className="w-[800px] h-[160px] border-y border-cyan-500/10 bg-cyan-500/[0.01] relative">
               <div className="absolute inset-0 flex items-center justify-center opacity-[0.05] text-5xl font-black uppercase tracking-widest text-slate-300">Hydrophobic Region</div>
            </div>
          </div>

          {previewPos && draggedType && (
            <div className="absolute opacity-40 pointer-events-none transition-all duration-75"
                 style={{ left: previewPos.x, top: previewPos.y, transform: 'translate(-50%, -50%)' }}>
               {draggedType === 'phospholipid' && <PhospholipidSVG rotation={previewPos.y > 200 ? 180 : 0} />}
               {draggedType === 'cholesterol' && <CholesterolSVG />}
               {draggedType === 'integral-protein' && <IntegralProteinSVG />}
               {draggedType === 'peripheral-protein' && <PeripheralProteinSVG />}
               {draggedType === 'carbohydrate' && <CarbohydrateSVG />}
            </div>
          )}

          <AnimatePresence>
            {molecules.map((mol) => (
              <motion.div
                key={mol.id}
                initial={{ scale: 0, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                style={{ 
                  position: 'absolute', 
                  left: mol.pos.x, 
                  top: mol.pos.y, 
                  transform: 'translate(-50%, -50%)',
                  zIndex: mol.type.includes('protein') ? 25 : 10
                }}
              >
                {mol.type === 'phospholipid' && <PhospholipidSVG rotation={mol.rotation} />}
                {mol.type === 'cholesterol' && <CholesterolSVG />}
                {mol.type === 'integral-protein' && <IntegralProteinSVG />}
                {mol.type === 'peripheral-protein' && <PeripheralProteinSVG />}
                {mol.type === 'carbohydrate' && <CarbohydrateSVG />}
              </motion.div>
            ))}
          </AnimatePresence>

          <AnimatePresence>
            {isLevelComplete && level <= Level.SELECTIVITY_TEST && (
              <motion.div initial={{ opacity: 0, y: 50 }} animate={{ opacity: 1, y: 0 }} className="absolute bottom-12 left-1/2 -translate-x-1/2 z-50">
                <button onClick={handleStartQuiz} className="px-10 py-4 bg-cyan-600 hover:bg-cyan-500 rounded-full font-bold shadow-2xl shadow-cyan-500/50 flex items-center gap-3 group transition-all">
                  Finalize Stage {level} Certification <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </button>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Quiz Pop-up Overlay */}
          <AnimatePresence>
            {showQuiz && (
              <motion.div 
                initial={{ opacity: 0 }} 
                animate={{ opacity: 1 }} 
                exit={{ opacity: 0 }}
                className="absolute inset-0 z-[100] bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-8"
              >
                <motion.div 
                  initial={{ scale: 0.9, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="max-w-2xl w-full bg-slate-900 border border-cyan-500/30 rounded-3xl p-10 shadow-2xl relative overflow-hidden"
                >
                  <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-cyan-500 to-transparent opacity-50" />
                  
                  {quizLoading ? (
                    <div className="flex flex-col items-center justify-center py-20 gap-4">
                      <Loader2 className="w-12 h-12 text-cyan-400 animate-spin" />
                      <p className="text-cyan-400 font-bold uppercase tracking-widest text-sm">Validating Assembly Standards...</p>
                    </div>
                  ) : currentQuiz ? (
                    <div className="space-y-8">
                      <div className="flex items-start gap-4">
                        <div className="p-3 bg-cyan-500/20 rounded-2xl">
                          <HelpCircle className="w-8 h-8 text-cyan-400" />
                        </div>
                        <div>
                          <h3 className="text-xs font-black uppercase tracking-widest text-slate-500 mb-1">Knowledge Verification: Stage {level}</h3>
                          <p className="text-xl font-bold leading-relaxed">{currentQuiz.question}</p>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 gap-3">
                        {currentQuiz.options.map((option, idx) => (
                          <button
                            key={idx}
                            onClick={() => !quizFeedback && handleAnswer(idx)}
                            disabled={!!quizFeedback}
                            className={`p-4 rounded-xl border text-left transition-all flex items-center justify-between group ${
                              quizFeedback 
                                ? idx === currentQuiz.correctIndex 
                                  ? 'bg-emerald-500/20 border-emerald-500/50' 
                                  : idx === (quizFeedback.correct ? -1 : -2) // purely for visual logic
                                    ? 'bg-red-500/20 border-red-500/50'
                                    : 'bg-slate-900 border-white/5 opacity-50'
                                : 'bg-slate-800/50 border-white/10 hover:border-cyan-500/50 hover:bg-slate-800'
                            }`}
                          >
                            <span className="text-sm font-medium">{option}</span>
                            {quizFeedback && idx === currentQuiz.correctIndex && <CheckCircle2 className="w-5 h-5 text-emerald-400" />}
                          </button>
                        ))}
                      </div>

                      {quizFeedback && (
                        <motion.div 
                          initial={{ opacity: 0, y: 10 }} 
                          animate={{ opacity: 1, y: 0 }}
                          className={`p-4 rounded-xl flex items-start gap-3 border ${
                            quizFeedback.correct ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300' : 'bg-red-500/10 border-red-500/30 text-red-300'
                          }`}
                        >
                          {quizFeedback.correct ? <CheckCircle2 className="w-5 h-5 mt-0.5" /> : <XCircle className="w-5 h-5 mt-0.5" />}
                          <p className="text-sm font-medium leading-relaxed">{quizFeedback.text}</p>
                        </motion.div>
                      )}
                    </div>
                  ) : null}
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>

          {level === Level.WIN && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="absolute inset-0 z-[100] bg-slate-950/95 backdrop-blur-2xl flex flex-col items-center justify-center text-center p-12">
              <Award className="w-24 h-24 text-emerald-400 mb-8" />
              <h1 className="text-6xl font-black mb-4 uppercase italic text-emerald-400 tracking-tighter">Bilayer Architect Prime</h1>
              <p className="text-xl text-slate-300 max-w-xl mb-12">Homeostasis maintained under environmental stress. Selective permeability is 100% efficient. Architect level: Master.</p>
              <button onClick={resetGame} className="px-12 py-4 bg-white text-slate-950 font-black rounded-full hover:bg-cyan-400 transition-all uppercase tracking-widest shadow-xl shadow-cyan-500/20">Restart Engine</button>
            </motion.div>
          )}
        </section>

        <aside className="w-80 bg-slate-900/30 border-l border-white/10 p-6 flex flex-col gap-6">
          <div className="space-y-4">
            <h2 className="text-xs font-bold text-slate-500 uppercase tracking-widest">Membrane Biosignals</h2>
            {level === Level.FLUIDITY_FLUX && (
              <div className="bg-slate-900/80 p-4 rounded-xl border border-white/10 space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-400 uppercase tracking-tighter">Liquid Crystal State</span>
                  <Activity className={`w-4 h-4 ${fluidity > 30 && fluidity < 70 ? 'text-green-400' : 'text-red-400'}`} />
                </div>
                <div className="h-4 w-full bg-slate-950 rounded-full overflow-hidden border border-white/5 relative">
                   <div className="absolute inset-0 bg-gradient-to-r from-blue-900/40 via-transparent to-red-900/40" />
                   <motion.div className="h-full bg-gradient-to-r from-cyan-500 via-emerald-400 to-amber-500" style={{ width: `${fluidity}%` }} />
                </div>
                <div className="flex items-center gap-2 text-slate-300 pt-1">
                  <Thermometer className="w-4 h-4 text-cyan-400" />
                  <span className="text-sm font-semibold mono">{temperature.toFixed(1)}°C</span>
                </div>
              </div>
            )}
            {(level === Level.SELECTIVITY_TEST || level === Level.WIN) && (
              <div className="bg-slate-900/80 p-4 rounded-xl border border-white/10 space-y-4">
                <div className="flex items-center justify-between text-xs text-slate-400 uppercase tracking-tighter">
                  <span>Permeability Stress-Test</span>
                  <ShieldCheck className="w-4 h-4 text-cyan-400" />
                </div>
                <div className="text-4xl font-black mono text-center text-cyan-400 tracking-tighter">{homeostasisTimer}s</div>
              </div>
            )}
            <div className="bg-slate-900/80 p-4 rounded-xl border border-white/10">
              <span className="block text-xs uppercase text-slate-400 mb-4 tracking-widest font-bold">Assembly Status</span>
              <div className="space-y-4">
                <ProgressItem label="Bilayer Integrity" current={molecules.filter(m => m.type === 'phospholipid').length} total={PHOSPHO_COUNT} />
                <ProgressItem label="Fluidity Buffers" current={molecules.filter(m => m.type === 'cholesterol').length} total={CHOLESTEROL_GOAL} />
                <ProgressItem label="Mosaic Density" current={molecules.filter(m => m.type.includes('protein')).length} total={PROTEIN_GOAL} />
                <ProgressItem label="Recognition Chains" current={molecules.filter(m => m.type === 'carbohydrate').length} total={CARB_GOAL} />
              </div>
            </div>
          </div>
        </aside>
      </main>

      <footer className="h-10 bg-cyan-600 flex items-center justify-center text-[10px] font-black uppercase tracking-[0.3em] text-white overflow-hidden whitespace-nowrap">
        <div className="animate-marquee">
          DESIGN THE BOUNDARY • MAINTAIN HOMEOSTASIS • SURVIVE ENVIRONMENTAL FLUX
        </div>
      </footer>

      <style>{`
        @keyframes marquee { 0% { transform: translateX(0); } 100% { transform: translateX(-50%); } }
        .animate-marquee { display: inline-block; animation: marquee 25s linear infinite; }
      `}</style>
    </div>
  );
};

const ProgressItem = ({ label, current, total }: { label: string, current: number, total: number }) => {
  const percent = Math.min(100, (current / total) * 100);
  return (
    <div className="space-y-1">
      <div className="flex justify-between text-[9px] font-bold text-slate-500 uppercase tracking-tighter">
        <span>{label}</span>
        <span>{Math.round(percent)}%</span>
      </div>
      <div className="h-1.5 w-full bg-slate-950 rounded-full overflow-hidden border border-white/5">
        <motion.div className="h-full bg-cyan-500" initial={{ width: 0 }} animate={{ width: `${percent}%` }} />
      </div>
    </div>
  );
};

export default App;