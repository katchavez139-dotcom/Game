
import React from 'react';

export const COLORS = {
  HEAD: '#38bdf8',
  TAIL: '#fbbf24',
  CHOLESTEROL: '#4ade80',
  INTEGRAL: '#a855f7',
  PERIPHERAL: '#ec4899',
  CARB: '#f43f5e',
  FLUID_BG: '#1e293b',
  DANGER: '#ef4444',
  SUCCESS: '#22c55e'
};

export const PhospholipidSVG = ({ rotation = 0 }: { rotation?: number }) => (
  <svg width="30" height="60" viewBox="0 0 30 60" style={{ transform: `rotate(${rotation}deg)` }}>
    <circle cx="15" cy="15" r="10" fill={COLORS.HEAD} />
    <path d="M12 25 Q10 40 12 55 M18 25 Q20 40 18 55" stroke={COLORS.TAIL} strokeWidth="3" fill="none" />
  </svg>
);

export const CholesterolSVG = () => (
  <svg width="15" height="30" viewBox="0 0 15 30">
    <rect x="2" y="5" width="11" height="20" rx="4" fill={COLORS.CHOLESTEROL} />
  </svg>
);

export const IntegralProteinSVG = () => (
  <svg width="60" height="100" viewBox="0 0 60 100">
    <path d="M10 5 Q30 0 50 5 L55 95 Q30 100 5 95 Z" fill={COLORS.INTEGRAL} opacity="0.9" />
    <rect x="20" y="20" width="20" height="60" rx="10" fill="white" opacity="0.2" />
  </svg>
);

export const PeripheralProteinSVG = () => (
  <svg width="40" height="30" viewBox="0 0 40 30">
    <ellipse cx="20" cy="15" rx="18" ry="12" fill={COLORS.PERIPHERAL} />
  </svg>
);

export const CarbohydrateSVG = () => (
  <svg width="30" height="40" viewBox="0 0 30 40">
    <path d="M15 40 L15 30 L5 20 M15 30 L25 20 M5 20 L5 10 M25 20 L25 10" stroke={COLORS.CARB} strokeWidth="3" fill="none" strokeLinecap="round" />
    <circle cx="5" cy="8" r="3" fill={COLORS.CARB} />
    <circle cx="25" cy="8" r="3" fill={COLORS.CARB} />
    <circle cx="15" cy="20" r="3" fill={COLORS.CARB} />
  </svg>
);

export const MOLECULE_DESCRIPTIONS = {
  phospholipid: "The building block of the membrane. Hydrophilic head and hydrophobic tails.",
  cholesterol: "Regulates membrane fluidity across different temperatures.",
  'integral-protein': "Firmly embedded proteins that often span the entire bilayer.",
  'peripheral-protein': "Proteins loosely bound to the surface of the membrane.",
  carbohydrate: "Short chains that form the glycocalyx for cell recognition."
};
