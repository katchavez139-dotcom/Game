
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function getEducationalFeedback(concept: string, event: string) {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `You are a biological expert in cell membranes. Briefly (1-2 sentences) explain the concept of ${concept} in the context of this game event: ${event}. Keep it engaging and educational for a high school or undergrad level.`,
    });
    return response.text || "Keep building your bilayer to maintain homeostasis!";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "The cell membrane is a dynamic fluid mosaic!";
  }
}

export async function generateQuizQuestion(nextLevelConcept: string): Promise<any> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Generate a very simple and clear multiple-choice question about ${nextLevelConcept}. The question should be introductory level, easy to understand for beginners, and avoid overly complex jargon. Include 4 options and a short, simple explanation for why the answer is correct.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            question: { type: Type.STRING },
            options: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            correctIndex: { type: Type.INTEGER },
            explanation: { type: Type.STRING }
          },
          required: ["question", "options", "correctIndex", "explanation"]
        }
      }
    });
    
    const text = response.text || "{}";
    return JSON.parse(text);
  } catch (error) {
    console.error("Quiz Generation Error:", error);
    return {
      question: "What is the primary role of the plasma membrane?",
      options: ["Making energy", "Deciding what goes in and out", "Building proteins", "Storing trash"],
      correctIndex: 1,
      explanation: "The membrane acts like a gatekeeper for the cell, controlling what enters and leaves."
    };
  }
}
