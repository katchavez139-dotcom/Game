
export enum Level {
  LIPID_LOGIC = 1,
  FLUIDITY_FLUX = 2,
  MOSAIC_MIX = 3,
  IDENTITY_CHECK = 4,
  SELECTIVITY_TEST = 5,
  WIN = 6
}

export type MoleculeType = 'phospholipid' | 'cholesterol' | 'integral-protein' | 'peripheral-protein' | 'carbohydrate' | 'oxygen' | 'glucose' | 'ion';

export interface Position {
  x: number;
  y: number;
}

export interface PlacedMolecule {
  id: string;
  type: MoleculeType;
  pos: Position;
  rotation?: number;
  layer?: 'top' | 'bottom';
  attachedToId?: string; // For carbohydrates attached to proteins/lipids
}

export interface QuizQuestion {
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface GameState {
  level: Level;
  molecules: PlacedMolecule[];
  fluidity: number; // 0 to 100
  temperature: number; // 0 to 100
  homeostasisTimer: number;
  isGameOver: boolean;
  score: number;
  feedback: string;
}
